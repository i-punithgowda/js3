import logo from './logo.svg';
import './App.css';
import React,{useState} from 'react'
import Header from './components/Header';
import Success from './components/Success';
function App() {

  const [name,setName]=useState('')
  const [address,setAddress]=useState('')
  const [email,setEmail]=useState('')
  const [dept,setDept]=useState('')
  const [sem,setSem]=useState('')
  const [fees,setFees]=useState('')
  const [phone,setPhone]=useState('')
  const[cgpa,setCGPA]=useState('')
  const [validatedState,setValidateState]=useState(false)
  const [result,setResult]=useState([])
  const [deletedState,setDeletedState]=useState(false)

  const validator=()=>{

    let stringPattern=/\d/
    let emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/
    let numPattern=/\D/
    let phonePattern=/^\d{10}$/
    if(name=="" || address=="" || email=="" || dept=="" || sem=="" || fees=="" || phone=="" || cgpa==""){
      alert("One or more fields are empty")
      setValidateState(false)

    }else{
      if(stringPattern.test(name)){
        alert("Invalid name")
        setValidateState(false)

      }else if(stringPattern.test(address)){
        alert("Invalid address")
        setValidateState(false)

      }else if(!emailPattern.test(email)){
        alert("Invalid email ID")
        setValidateState(false)

      }else if(stringPattern.test(dept)){
        alert("Invalid department name")
        setValidateState(false)

      }else if(numPattern.test(sem)){
        alert("Invalid sem")
        setValidateState(false)

      }else if(numPattern.test(fees)){
        alert("Invalid fees")
        setValidateState(false)

      }else if(!phonePattern.test(phone)){
        alert("Invalid phone number")
        setValidateState(false)

      }
      else if(numPattern.test(cgpa)){
        alert("Enter valid CGPA")
        setValidateState(false)
      }else{
        setValidateState(true)
        setResult([
          {name:name,address:address,email:email,phone:phone,sem:sem,fees:fees,dept:dept,cgpa:cgpa}
        ])
       

       
      }
    }
  

  
  }

    
  
  const updator=()=>{
    if(!validatedState){
      alert("No data found")
    }else{
      validator()
    }
  }
  

  const deletor=()=>{

    if(!validatedState){
      alert("No data found")
    }else{
      setName('')
      setAddress('')
      setCGPA('')
      setDept('')
      setEmail('')
      setFees('')
      setPhone('')
      setResult('')
      setSem('')
      setResult([
        {name:' ',address:' ',email:' ',phone:' ',sem:' ',fees:' ',dept:' ',cgpa:' '}
      ])
      setDeletedState(true)

    }

  }




  return (
    <div className="container">
     
     <div className="rcontainer">
     <Header />
     <input type="text" placeholder='Name' value={name} onChange={(e)=>setName(e.target.value)} />
     <input type="text" placeholder="Address" value={address} onChange={(e)=>setAddress(e.target.value)} />
     <input type="text" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
     <input type="text" placeholder="Department" value={dept} onChange={(e)=>setDept(e.target.value)} />
     <input type="text" placeholder="Sem" value={sem} onChange={(e)=>setSem(e.target.value)} />
     <input type="text" placeholder="Fees" value={fees} onChange={(e)=>setFees(e.target.value)} />
     <input type="text" placeholder="Phone" value={phone} onChange={(e)=>setPhone(e.target.value)} />
    <input type="text" placeholder="CGPA" value={cgpa} onChange={(e)=>setCGPA(e.target.value)} />
     <button id="btn-signup"
     onClick={validator}
     >Click here to register</button>
       <button id="btn-signup"
     onClick={updator}
     >Update</button>
       <button id="btn-signup"
     onClick={deletor}
     >Delete</button>

     </div>
     
     

     

     
    {validatedState && !deletedState ?
      <div className="success">
        <Success data={result} />
      </div>
       : validatedState && deletedState ?
       <div className="success">
        <Success data={result} />
      </div>
        : null}
    

    </div>
  );
}

export default App;
